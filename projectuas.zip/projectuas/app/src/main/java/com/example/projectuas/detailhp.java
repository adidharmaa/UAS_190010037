package com.example.projectuas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class detailhp extends AppCompatActivity {
    TextView tvnamadata;
    TextView tvdeskripsidata;
    TextView tvmerkdata;
    ImageView ivhp;
    TextView tvhargadata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailhp);
        ivhp=findViewById(R.id.imghp);
        String url= getIntent().getStringExtra("img");
        Glide.with(this)
                .load(url)
                .centerCrop()
                .into(ivhp);

        tvnamadata=findViewById(R.id.tvnama);
        tvnamadata.setText(getIntent().getStringExtra("nama"));
        tvdeskripsidata= findViewById(R.id.tvdeskripsi);
        tvdeskripsidata.setText(getIntent().getStringExtra("deskripsi"));
        tvmerkdata = findViewById(R.id.tvmerk);
        tvmerkdata.setText(getIntent().getStringExtra("merk"));
        tvhargadata = findViewById(R.id.tvharga);
        tvhargadata.setText(getIntent().getStringExtra("harga"));



    }
}