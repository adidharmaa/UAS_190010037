package com.example.projectuas;

public class list {
    private String nama;
    private  String harga;
    private String gambar;
    private  String deskripsi;
    private  String merk;


    public list(String datanama, String dataharga, String datagambar, String datadeskripsi, String datamerk){
        nama = datanama;
        harga = dataharga;
        gambar = datagambar;
        deskripsi = datadeskripsi;
        merk = datamerk;
    }

    public String getNama() {
        return nama;
    }

    public String getHarga() {
        return harga;
    }

    public String getGambar() {
        return gambar;
    }

    public String getDeskripsi() { return deskripsi; }

    public String getMerk() { return merk; }


}
